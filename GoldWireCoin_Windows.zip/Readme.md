<div style="padding-top:2%;padding-left:7%">RECENTRY UPDATE！：<br>
<ul style="; padding-left: 1%;"><li>DELETED GUI</li><li>Block compressable</li></ul>
<image width="854px" height="480px" src="scr.png"/></div>